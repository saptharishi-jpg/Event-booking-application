function Navbar({ user, page, setPage, onLogout, unreadCount }) {
  return (
    <nav className="navbar">
      <button className="logo" onClick={() => setPage("home")}>SmartEvent</button>
      <div className="nav-links">
        <button onClick={() => setPage("home")}>Events</button>
        <button onClick={() => setPage("bookings")}>Bookings</button>
        <button onClick={() => setPage("tickets")}>Tickets</button>
        <button onClick={() => setPage("notifications")}>Notifications ({unreadCount})</button>
        <span>Hi, {user?.username}</span>
        <button className="danger" onClick={onLogout}>Logout</button>
      </div>
    </nav>
  );
}

export default Navbar;
