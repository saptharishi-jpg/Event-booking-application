function TicketCard({ ticket, apiUrl }) {
  const qrUrl = `${apiUrl}${ticket.qr_code_url}`;

  return (
    <div className="card ticket-card">
      <div>
        <h3>{ticket.event_title}</h3>
        <p>Ticket Code: <strong>{ticket.ticket_code}</strong></p>
        <p>Date: {new Date(ticket.event_date).toLocaleString()}</p>
        <p>Location: {ticket.location}</p>
        <p>Quantity: {ticket.ticket_quantity}</p>
        <a href={qrUrl} download={`${ticket.ticket_code}.png`} className="button-link">Download QR</a>
      </div>
      <img src={qrUrl} alt="Ticket QR code" className="qr-code" />
    </div>
  );
}

export default TicketCard;
