import { useEffect, useState } from "react";
import api, { authHeaders } from "./api";
import Navbar from "./components/Navbar";
import ProtectedRoute from "./components/ProtectedRoute";
import { LoginPage, RegisterPage } from "./pages/AuthPages";
import HomePage from "./pages/HomePage";
import EventDetailsPage from "./pages/EventDetailsPage";
import BookingConfirmationPage from "./pages/BookingConfirmationPage";
import BookingHistoryPage from "./pages/BookingHistoryPage";
import TicketsPage from "./pages/TicketsPage";
import NotificationsPage from "./pages/NotificationsPage";

function App() {
  const [token, setToken] = useState(localStorage.getItem("token"));
  const [user, setUser] = useState(JSON.parse(localStorage.getItem("user") || "null"));
  const [page, setPage] = useState(token ? "home" : "login");
  const [selectedEvent, setSelectedEvent] = useState(null);
  const [confirmation, setConfirmation] = useState(null);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [unreadCount, setUnreadCount] = useState(0);

  function showMessage(text) {
    setMessage(text);
    setError("");
  }

  function showError(text) {
    setError(text);
    setMessage("");
  }

  function saveLogin(data) {
    localStorage.setItem("token", data.access_token);
    localStorage.setItem("user", JSON.stringify(data.user));
    setToken(data.access_token);
    setUser(data.user);
    setPage("home");
  }

  function logout() {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    setToken(null);
    setUser(null);
    setPage("login");
    setSelectedEvent(null);
  }

  async function openEvent(id) {
    try {
      const response = await api.get(`/events/${id}`);
      setSelectedEvent(response.data);
      setPage("details");
    } catch {
      showError("Could not open event.");
    }
  }

  function onBooked(data) {
    setConfirmation(data);
    setPage("confirmation");
  }

  async function loadUnreadCount() {
    if (!token) return;
    try {
      const response = await api.get("/notifications", { headers: authHeaders() });
      setUnreadCount(response.data.filter((item) => !item.is_read).length);
    } catch {
      // Notification count is optional; do not stop the application if it fails.
    }
  }

  useEffect(() => {
    loadUnreadCount();
  }, [token, page]);

  if (!token) {
    return (
      <>
        {message && <div className="message">{message}</div>}
        {error && <div className="error">{error}</div>}
        {page === "register" ? (
          <RegisterPage goLogin={() => setPage("login")} showMessage={showMessage} showError={showError} />
        ) : (
          <LoginPage onLogin={saveLogin} goRegister={() => setPage("register")} showMessage={showMessage} showError={showError} />
        )}
      </>
    );
  }

  function renderPage() {
    switch (page) {
      case "home":
        return <HomePage onViewEvent={openEvent} showError={showError} />;
      case "details":
        return <EventDetailsPage event={selectedEvent} onBack={() => setPage("home")} onBooked={onBooked} showMessage={showMessage} showError={showError} />;
      case "confirmation":
        return <BookingConfirmationPage booking={confirmation?.booking} ticketCode={confirmation?.ticket_code} goTickets={() => setPage("tickets")} goHome={() => setPage("home")} />;
      case "bookings":
        return <BookingHistoryPage showError={showError} />;
      case "tickets":
        return <TicketsPage showError={showError} />;
      case "notifications":
        return <NotificationsPage showError={showError} onChanged={loadUnreadCount} />;
      default:
        return <HomePage onViewEvent={openEvent} showError={showError} />;
    }
  }

  return (
    <div>
      <Navbar user={user} page={page} setPage={setPage} onLogout={logout} unreadCount={unreadCount} />
      {message && <div className="message">{message}</div>}
      {error && <div className="error">{error}</div>}
      <ProtectedRoute token={token}>{renderPage()}</ProtectedRoute>
    </div>
  );
}

export default App;
