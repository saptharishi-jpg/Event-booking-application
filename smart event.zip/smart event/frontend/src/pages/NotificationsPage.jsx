import { useEffect, useState } from "react";
import api, { authHeaders } from "../api";
import NotificationDropdown from "../components/NotificationDropdown";

function NotificationsPage({ showError, onChanged }) {
  const [notifications, setNotifications] = useState([]);

  async function load() {
    try {
      const response = await api.get("/notifications", { headers: authHeaders() });
      setNotifications(response.data);
    } catch {
      showError("Could not load notifications.");
    }
  }

  async function markRead(id) {
    try {
      await api.patch(`/notifications/${id}/read`, {}, { headers: authHeaders() });
      await load();
      onChanged();
    } catch {
      showError("Could not update notification.");
    }
  }

  useEffect(() => { load(); }, []);

  return (
    <main className="container">
      <h1>Notifications</h1>
      <NotificationDropdown notifications={notifications} onRead={markRead} />
    </main>
  );
}

export default NotificationsPage;
