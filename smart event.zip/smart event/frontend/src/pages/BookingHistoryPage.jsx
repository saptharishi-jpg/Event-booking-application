import { useEffect, useState } from "react";
import api, { authHeaders } from "../api";

function BookingHistoryPage({ showError }) {
  const [bookings, setBookings] = useState([]);

  useEffect(() => {
    api.get("/bookings", { headers: authHeaders() }).then((response) => setBookings(response.data)).catch(() => showError("Could not load booking history."));
  }, []);

  return (
    <main className="container">
      <h1>Booking History</h1>
      {bookings.map((booking) => (
        <div className="card booking" key={booking.id}>
          <h3>{booking.event_title}</h3>
          <p>{new Date(booking.event_date).toLocaleString()} | {booking.location}</p>
          <p>Tickets: {booking.ticket_quantity}</p>
          <p>Total: ₹{booking.total_price}</p>
          <p>Status: <strong>{booking.booking_status}</strong></p>
        </div>
      ))}
      {!bookings.length && <p>No bookings yet.</p>}
    </main>
  );
}

export default BookingHistoryPage;
