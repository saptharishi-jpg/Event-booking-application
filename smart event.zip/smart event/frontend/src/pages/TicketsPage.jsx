import { useEffect, useState } from "react";
import api, { authHeaders } from "../api";
import TicketCard from "../components/TicketCard";

function TicketsPage({ showError }) {
  const [tickets, setTickets] = useState([]);
  const apiUrl = import.meta.env.VITE_API_URL || "http://localhost:8000";

  useEffect(() => {
    api.get("/tickets", { headers: authHeaders() }).then((response) => setTickets(response.data)).catch(() => showError("Could not load tickets."));
  }, []);

  return (
    <main className="container">
      <h1>My Tickets</h1>
      {tickets.map((ticket) => <TicketCard key={ticket.id} ticket={ticket} apiUrl={apiUrl} />)}
      {!tickets.length && <p>No tickets available.</p>}
    </main>
  );
}

export default TicketsPage;
