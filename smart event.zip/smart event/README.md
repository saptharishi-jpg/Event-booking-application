# SmartEvent – Event Discovery & Ticket Booking System

Event discovery and ticket booking application built with **FastAPI, SQLAlchemy, SQLite, React, Vite, Axios, JWT authentication, bcrypt, and QR code generation**.

The project follows **Phase 1: Event Discovery & Booking Platform** and supports registration, login, event discovery, ticket booking, digital tickets, booking history, and notifications.

## 1. Project Setup

### Technologies

  Technology        Purpose
  ----------------- -----------------------------
  Python            Backend programming
  FastAPI           REST API
  Uvicorn           Backend server
  SQLAlchemy        Database ORM
  SQLite            Default database
  Pydantic          Request validation
  JWT               User authentication
  bcrypt            Password hashing
  React             Frontend UI
  Vite              Frontend development server
  Axios             Frontend API requests
  QRCode            Digital ticket QR generation

### Prerequisites

-   Python 3.10+
-   Node.js and npm
-   VS Code or another code editor
-   A modern web browser

Install backend dependencies:

``` powershell
pip install -r backend/requirements.txt
```

If you are already inside the `backend` directory:

``` powershell
pip install -r requirements.txt
```

## 2. Database Configuration

The project uses SQLite by default:

``` env
DATABASE_URL=sqlite:///./smartevent.db
```

The application creates the required database tables automatically when FastAPI starts.

Main tables:

-   `users`
-   `events`
-   `bookings`
-   `tickets`
-   `notifications`

### Table fields

-   **Users:** `id`, `username`, `email`, `hashed_password`, `created_at`
-   **Events:** `id`, `title`, `description`, `category`, `location`, `event_date`, `ticket_price`, `banner_image`, `created_at`, `available_tickets`
-   **Bookings:** `id`, `user_id`, `event_id`, `ticket_quantity`, `total_price`, `booking_status`, `created_at`
-   **Tickets:** `id`, `booking_id`, `ticket_code`, `qr_code_url`, `created_at`
-   **Notifications:** `id`, `user_id`, `title`, `message`, `type`, `is_read`, `created_at`

`available_tickets` is used for booking availability. `banner_image` is retained because it is part of the required Events schema; the supplied project does not use image assets.

## 3. Environment Variables

The backend uses a `.env` file for the database connection and JWT secret.

Create or update `backend/.env`:

``` env
SECRET_KEY=change-this-to-a-random-secret-key
DATABASE_URL=sqlite:///./smartevent.db
```

The frontend uses `frontend/.env`:

``` env
VITE_API_URL=http://localhost:8000
```

**Never commit real production secrets or passwords to source control.**

  Variable          Purpose
  ----------------- ---------------------------------------
  `SECRET_KEY`      JWT signing secret
  `DATABASE_URL`    SQLite database connection
  `VITE_API_URL`    FastAPI URL used by the React frontend

## 4. Authentication Configuration

The application uses JWT authentication for protected user actions.

### Registration and Login

Users register with username, email, and password. Passwords are hashed with bcrypt. Login returns a JWT access token, which React stores in `localStorage` and sends as `Authorization: Bearer <token>`.

Protected features: profile, booking, booking history, tickets, and notifications.

## 5. Backend Execution Steps

Open the VS Code terminal in the project directory.

``` powershell
cd backend

```

Activate it on Windows PowerShell:

``` powershell
.\Scripts\Activate.ps1
```

Install dependencies:

``` powershell
pip install -r requirements.txt
```

Start FastAPI:

``` powershell
uvicorn main:app --reload
```

Backend:

``` text
http://localhost:8000
```

Swagger:

``` text
http://localhost:8000/docs
```

ReDoc:

``` text
http://localhost:8000/redoc
```

## 6. Frontend Execution Steps

Open another VS Code terminal.

Go to the frontend directory:

``` powershell
cd frontend
```

Install dependencies:

``` powershell
npm install
```

If PowerShell displays an error saying that `npm.ps1` cannot be loaded because running scripts are disabled, use:

``` powershell
npm.cmd install
```

Start Vite:

``` powershell
npm run dev
```

If PowerShell blocks `npm.ps1`, use:

``` powershell
npm.cmd run dev
```

Frontend:

``` text
http://localhost:5173
```

The frontend uses:

``` env
VITE_API_URL=http://localhost:8000
```

## 7. Main Features

### Authentication

``` text
POST /auth/register
POST /auth/login
GET  /auth/profile
```

JWT authentication protects user-specific operations.

### Event Discovery

``` text
GET /events
GET /events/{event_id}
GET /events/categories/list
```

The event listing API supports:

``` text
GET /events?category=Tech
GET /events?search=Python
GET /events?category=Tech&search=Python
```

Supported categories are:

-   Music
-   Tech
-   Sports
-   Business

The event listing is ordered by event date.

### Ticket Booking

``` text
POST /bookings
GET  /bookings
```

The booking API:

-   Requires JWT authentication.
-   Checks that the event exists.
-   Validates the ticket quantity with Pydantic.
-   Checks available tickets.
-   Calculates the total price automatically.
-   Reduces the available ticket count.
-   Creates a confirmed booking.

The maximum ticket quantity in one booking is 10.

### Digital Tickets and QR Codes

``` text
GET /tickets
GET /tickets/{ticket_code}/qr
GET /tickets/verify/{ticket_code}
```

After a successful booking:

1.  A unique ticket code is generated.
2.  A ticket record is created.
3.  A QR endpoint is stored for the ticket.
4.  The QR image is generated when the QR endpoint is requested.
5.  The user can view and download the QR code from the Tickets page.

### Notifications

``` text
GET   /notifications
PATCH /notifications/{notification_id}/read
```

A booking confirmation creates a `BOOKING` notification.

The notifications API also checks booked events and creates an `EVENT` reminder when an event is within approximately three days.

Notifications can be marked as read only by the authenticated owner of the notification.

## 8. Frontend Pages

Required pages implemented in the React application:

``` text
Register Page
Login Page
Home Page (Events Listing)
Event Details Page
Booking Confirmation Page
Booking History Page
Tickets Page
Notifications Page
```

The Home page supports event listing, title search, category filtering, price, date, location, and availability. Event Details supports quantity selection and booking. Booking Confirmation shows the booking and ticket code. Booking History shows the user's bookings. Tickets shows QR tickets and download links. Notifications shows notifications and mark-as-read actions.

## 9. React Components

``` text
Navbar
EventCard
TicketCard
NotificationDropdown
ProtectedRoute
```

These components provide navigation, event cards, digital tickets, notification display/actions, and protection for the authenticated application area.

## 10. API and Database Relationships

``` text
User 1 ----< Booking >---- 1 Event
User 1 ----< Notification
Booking 1 ----< Ticket
```

Bookings connect users to events; tickets belong to bookings; notifications belong to users.

## 11. Booking Workflow

``` text
Event Details → Quantity → POST /bookings → JWT/Event check
→ Availability → Total price → Booking → Ticket → Notification
→ Booking Confirmation → Digital QR Ticket
```

## 12. QR Ticket Workflow

``` text
Confirmed Booking → Unique Ticket Code → Ticket Record
→ GET /tickets/{ticket_code}/qr → QR Generated → Display/Download
```

Verification endpoint:

``` text
GET /tickets/verify/{ticket_code}
```

## 13. Security Notes

-   Never commit the real `.env` file.
-   Never expose the JWT `SECRET_KEY` in the frontend.
-   Passwords are stored as bcrypt hashes, not plain text.
-   JWT authentication is required for booking and user-specific APIs.
-   Booking history is filtered using the authenticated user's ID.
-   Notifications can only be marked as read by their owner.
-   Ticket information is returned through authenticated user ticket APIs.
-   Pydantic validates registration, login, and booking input.
-   Proper HTTP errors are returned for invalid users, events, tickets, and notifications.

## 14. Typical Startup Order

### Terminal 1 --- FastAPI

``` powershell
cd backend
.\venv\Scripts\Activate.ps1
uvicorn main:app --reload
```

### Terminal 2 --- React/Vite

``` powershell
cd frontend
npm install
npm run dev
```

If PowerShell blocks npm scripts:

``` powershell
npm.cmd install
npm.cmd run dev
```

Then open:

``` text
http://localhost:5173
```

## 15. Troubleshooting

### PowerShell blocks npm

If you see:

``` text
npm.ps1 cannot be loaded because running scripts is disabled on this system
```

Use:

``` powershell
npm.cmd install
npm.cmd run dev
```

### 401 Unauthorized

Log in again and make sure the frontend has a valid JWT token in `localStorage`.

### Registration failed

Check that:

1.  The email is valid.
2.  The username contains at least two characters.
3.  The password contains at least six characters.
4.  The email has not already been registered.

### Booking failed

Check that:

1.  You are logged in.
2.  The event exists.
3.  The ticket quantity is between 1 and 10.
4.  Enough tickets are available.
5.  FastAPI is running.

### Frontend cannot connect to backend

Check:

``` env
VITE_API_URL=http://localhost:8000
```

Also make sure FastAPI is running at port `8000`.

### QR code is not displayed

Check that:

1.  The booking was confirmed.
2.  A ticket was created.
3.  FastAPI is running.
4.  The frontend API URL points to the FastAPI server.

## 16. Project Checklist

-   FastAPI backend
-   SQLite database
-   SQLAlchemy models
-   Users table
-   Events table
-   Bookings table
-   Tickets table
-   Notifications table
-   User registration
-   User login
-   JWT authentication
-   bcrypt password hashing
-   Protected booking routes
-   User profile endpoint
-   Event listing
-   Event details
-   Category filtering
-   Event title search
-   Ticket booking
-   Ticket availability validation
-   Automatic total price calculation
-   Booking history
-   Unique ticket code
-   QR ticket generation
-   QR ticket download
-   Ticket verification endpoint
-   Booking notifications
-   Upcoming event reminders
-   Mark notifications as read
-   React + Vite frontend
-   Axios API integration
-   localStorage JWT storage
-   Protected frontend area
-   Responsive UI
-   Loading and error messages
-   Swagger documentation

## Author

Saptharishi reddy D
