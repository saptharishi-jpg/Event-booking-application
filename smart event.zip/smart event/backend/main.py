from datetime import datetime, timedelta
from io import BytesIO
import os
import secrets

import bcrypt
import qrcode
from dotenv import load_dotenv
from fastapi import Depends, FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from jose import JWTError, jwt
from pydantic import BaseModel, EmailStr, Field
from sqlalchemy import Column, DateTime, Float, ForeignKey, Integer, String, Text, create_engine
from sqlalchemy.orm import Session, declarative_base, sessionmaker

load_dotenv()

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./smartevent.db")
SECRET_KEY = os.getenv("SECRET_KEY", "change-this-secret-key")

engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(bind=engine)
Base = declarative_base()


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True)
    username = Column(String(50), nullable=False)
    email = Column(String(120), unique=True, nullable=False)
    hashed_password = Column(String, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)


class Event(Base):
    __tablename__ = "events"

    id = Column(Integer, primary_key=True)
    title = Column(String(150), nullable=False)
    description = Column(Text, nullable=False)
    category = Column(String(30), nullable=False)
    location = Column(String(150), nullable=False)
    event_date = Column(DateTime, nullable=False)
    ticket_price = Column(Float, nullable=False)
    banner_image = Column(String, nullable=True)
    available_tickets = Column(Integer, default=100)
    created_at = Column(DateTime, default=datetime.utcnow)


class Booking(Base):
    __tablename__ = "bookings"

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    event_id = Column(Integer, ForeignKey("events.id"), nullable=False)
    ticket_quantity = Column(Integer, nullable=False)
    total_price = Column(Float, nullable=False)
    booking_status = Column(String(20), default="CONFIRMED")
    created_at = Column(DateTime, default=datetime.utcnow)


class Ticket(Base):
    __tablename__ = "tickets"

    id = Column(Integer, primary_key=True)
    booking_id = Column(Integer, ForeignKey("bookings.id"), nullable=False)
    ticket_code = Column(String(50), unique=True, nullable=False)
    qr_code_url = Column(String, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)


class Notification(Base):
    __tablename__ = "notifications"

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    title = Column(String(150), nullable=False)
    message = Column(Text, nullable=False)
    type = Column(String(20), nullable=False)
    is_read = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)


Base.metadata.create_all(bind=engine)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
        
app = FastAPI(title="SmartEvent API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

security = HTTPBearer()

def create_token(user_id: int):
    expires = datetime.utcnow() + timedelta(hours=2)
    return jwt.encode({"user_id": user_id, "exp": expires}, SECRET_KEY, algorithm="HS256")


def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: Session = Depends(get_db),
):
    try:
        payload = jwt.decode(credentials.credentials, SECRET_KEY, algorithms=["HS256"])
        user_id = payload.get("user_id")
    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid or expired token")

    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=401, detail="User not found")
    return user


def event_to_dict(event):
    return {
        "id": event.id,
        "title": event.title,
        "description": event.description,
        "category": event.category,
        "location": event.location,
        "event_date": event.event_date.isoformat(),
        "ticket_price": event.ticket_price,
        "banner_image": event.banner_image,
        "available_tickets": event.available_tickets,
    }


def booking_to_dict(booking, event):
    return {
        "id": booking.id,
        "event_id": event.id,
        "event_title": event.title,
        "event_date": event.event_date.isoformat(),
        "location": event.location,
        "ticket_quantity": booking.ticket_quantity,
        "total_price": booking.total_price,
        "booking_status": booking.booking_status,
        "created_at": booking.created_at.isoformat(),
    }


def create_ticket_and_notification(db, booking, event, user):
    ticket_code = "TKT-" + secrets.token_hex(6).upper()
    while db.query(Ticket).filter(Ticket.ticket_code == ticket_code).first():
        ticket_code = "TKT-" + secrets.token_hex(6).upper()

    ticket = Ticket(
        booking_id=booking.id,
        ticket_code=ticket_code,
        qr_code_url=f"/tickets/{ticket_code}/qr",
    )
    db.add(ticket)

    notification = Notification(
        user_id=user.id,
        title="Booking confirmed",
        message=f"Your booking for {event.title} is confirmed.",
        type="BOOKING",
        is_read=0,
    )
    db.add(notification)
    db.commit()
    return ticket

class RegisterData(BaseModel):
    username: str = Field(min_length=2, max_length=50)
    email: EmailStr
    password: str = Field(min_length=6, max_length=100)


class LoginData(BaseModel):
    email: EmailStr
    password: str


class BookingData(BaseModel):
    event_id: int
    ticket_quantity: int = Field(ge=1, le=10)

def add_sample_events():
    db = SessionLocal()
    if db.query(Event).count() == 0:
        db.add_all([
            Event(
                title="Hyderabad Tech Meetup",
                description="Learn about Python, APIs and modern web development.",
                category="Tech",
                location="HITEX, Hyderabad",
                event_date=datetime(2026, 12, 15, 10, 0),
                ticket_price=999,
                banner_image=None,
                available_tickets=100,
            ),
            Event(
                title="Live Music Night",
                description="Enjoy live music and performances with friends.",
                category="Music",
                location="Gachibowli, Hyderabad",
                event_date=datetime(2026, 12, 20, 18, 0),
                ticket_price=1499,
                banner_image=None,
                available_tickets=200,
            ),
            Event(
                title="Business Conference",
                description="Talks about startups, business and leadership.",
                category="Business",
                location="HICC, Hyderabad",
                event_date=datetime(2027, 1, 10, 9, 0),
                ticket_price=1999,
                banner_image=None,
                available_tickets=150,
            ),
            Event(
                title="Sports Meet",
                description="A day of sports activities and competitions.",
                category="Sports",
                location="LB Stadium, Hyderabad",
                event_date=datetime(2027, 1, 20, 8, 0),
                ticket_price=799,
                banner_image=None,
                available_tickets=300,
            ),
        ])
        db.commit()
    db.close()


add_sample_events()

@app.get("/")
def home():
    return {"message": "SmartEvent API is running"}

@app.post("/auth/register")
def register(data: RegisterData, db: Session = Depends(get_db)):
    if db.query(User).filter(User.email == data.email).first():
        raise HTTPException(status_code=400, detail="Email already registered")

    hashed = bcrypt.hashpw(data.password.encode(), bcrypt.gensalt()).decode()
    user = User(username=data.username, email=data.email, hashed_password=hashed)
    db.add(user)
    db.commit()
    db.refresh(user)
    return {"message": "Registration successful"}


@app.post("/auth/login")
def login(data: LoginData, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == data.email).first()
    if not user or not bcrypt.checkpw(data.password.encode(), user.hashed_password.encode()):
        raise HTTPException(status_code=401, detail="Invalid email or password")

    return {
        "access_token": create_token(user.id),
        "token_type": "bearer",
        "user": {"id": user.id, "username": user.username, "email": user.email},
    }


@app.get("/auth/profile")
def profile(user: User = Depends(get_current_user)):
    return {
        "id": user.id,
        "username": user.username,
        "email": user.email,
        "created_at": user.created_at.isoformat(),
    }

@app.get("/events")
def get_events(category: str | None = None, search: str | None = None, db: Session = Depends(get_db)):
    query = db.query(Event)
    if category and category != "All":
        query = query.filter(Event.category == category)
    if search:
        query = query.filter(Event.title.ilike(f"%{search}%"))

    return [event_to_dict(event) for event in query.order_by(Event.event_date).all()]


@app.get("/events/{event_id}")
def get_event(event_id: int, db: Session = Depends(get_db)):
    event = db.query(Event).filter(Event.id == event_id).first()
    if not event:
        raise HTTPException(status_code=404, detail="Event not found")
    return event_to_dict(event)


@app.get("/events/categories/list")
def get_categories():
    return ["All", "Music", "Tech", "Sports", "Business"]

@app.post("/bookings")
def create_booking(
    data: BookingData,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    event = db.query(Event).filter(Event.id == data.event_id).first()
    if not event:
        raise HTTPException(status_code=404, detail="Event not found")

    if data.ticket_quantity > event.available_tickets:
        raise HTTPException(status_code=400, detail="Tickets are sold out or unavailable")

    total_price = event.ticket_price * data.ticket_quantity
    booking = Booking(
        user_id=user.id,
        event_id=event.id,
        ticket_quantity=data.ticket_quantity,
        total_price=total_price,
        booking_status="CONFIRMED",
    )
    event.available_tickets -= data.ticket_quantity
    db.add(booking)
    db.commit()
    db.refresh(booking)

    ticket = create_ticket_and_notification(db, booking, event, user)
    return {
        "message": "Booking confirmed",
        "booking": booking_to_dict(booking, event),
        "ticket_code": ticket.ticket_code,
    }


@app.get("/bookings")
def get_bookings(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    bookings = db.query(Booking).filter(Booking.user_id == user.id).order_by(Booking.created_at.desc()).all()
    result = []
    for booking in bookings:
        event = db.query(Event).filter(Event.id == booking.event_id).first()
        if event:
            result.append(booking_to_dict(booking, event))
    return result

@app.get("/tickets")
def get_tickets(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    bookings = db.query(Booking).filter(Booking.user_id == user.id).all()
    booking_ids = [booking.id for booking in bookings]
    tickets = db.query(Ticket).filter(Ticket.booking_id.in_(booking_ids)).all() if booking_ids else []

    result = []
    for ticket in tickets:
        booking = db.query(Booking).filter(Booking.id == ticket.booking_id).first()
        event = db.query(Event).filter(Event.id == booking.event_id).first() if booking else None
        if booking and event:
            result.append({
                "id": ticket.id,
                "ticket_code": ticket.ticket_code,
                "qr_code_url": ticket.qr_code_url,
                "event_title": event.title,
                "event_date": event.event_date.isoformat(),
                "location": event.location,
                "ticket_quantity": booking.ticket_quantity,
            })
    return result


@app.get("/tickets/{ticket_code}/qr")
def get_qr_code(ticket_code: str, db: Session = Depends(get_db)):
    ticket = db.query(Ticket).filter(Ticket.ticket_code == ticket_code).first()
    if not ticket:
        raise HTTPException(status_code=404, detail="Ticket not found")

    qr = qrcode.make(ticket.ticket_code)
    image = BytesIO()
    qr.save(image, format="PNG")
    image.seek(0)
    return StreamingResponse(image, media_type="image/png")


@app.get("/tickets/verify/{ticket_code}")
def verify_ticket(ticket_code: str, db: Session = Depends(get_db)):
    ticket = db.query(Ticket).filter(Ticket.ticket_code == ticket_code).first()
    if not ticket:
        raise HTTPException(status_code=404, detail="Invalid ticket")
    return {"valid": True, "ticket_code": ticket.ticket_code}


@app.get("/notifications")
def get_notifications(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    bookings = db.query(Booking).filter(Booking.user_id == user.id).all()

    
    for booking in bookings:
        event = db.query(Event).filter(Event.id == booking.event_id).first()
        if not event:
            continue
        days_left = (event.event_date - datetime.utcnow()).days
        if 0 <= days_left <= 3:
            exists = db.query(Notification).filter(
                Notification.user_id == user.id,
                Notification.type == "EVENT",
                Notification.message.like(f"%{event.title}%"),
            ).first()
            if not exists:
                db.add(Notification(
                    user_id=user.id,
                    title="Upcoming event",
                    message=f"{event.title} is coming soon.",
                    type="EVENT",
                    is_read=0,
                ))
    db.commit()

    notifications = db.query(Notification).filter(
        Notification.user_id == user.id
    ).order_by(Notification.created_at.desc()).all()
    return [
        {
            "id": n.id,
            "title": n.title,
            "message": n.message,
            "type": n.type,
            "is_read": bool(n.is_read),
            "created_at": n.created_at.isoformat(),
        }
        for n in notifications
    ]


@app.patch("/notifications/{notification_id}/read")
def mark_notification_read(
    notification_id: int,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    notification = db.query(Notification).filter(
        Notification.id == notification_id,
        Notification.user_id == user.id,
    ).first()
    if not notification:
        raise HTTPException(status_code=404, detail="Notification not found")
    notification.is_read = 1
    db.commit()
    return {"message": "Notification marked as read"}
